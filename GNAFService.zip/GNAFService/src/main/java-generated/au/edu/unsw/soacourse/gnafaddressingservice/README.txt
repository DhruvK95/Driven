// README.txt

Student ID: z5017483
Name: Dhruv Kaushik

Installation Guide

- How to compile, deploy the service code (step-by-step)

- How to setup SQLite (e.g., where to put the database file)
    The gnaf.db file should be placed in the resources folder 'Asi1/src/main/resources/'

- Specify if the assessor needs to prepare anything before running your solution? (e.g., do you assume there is a directory named 'XYZ' somewhere?)

- Specify if there is anything else you want to mention to help the assessor
    :)