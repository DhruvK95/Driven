@javax.xml.bind.annotation.XmlSchema(namespace = "http://GNAFAddressingService.soacourse.unsw.edu.au")
package au.edu.unsw.soacourse.gnafaddressingservice;
